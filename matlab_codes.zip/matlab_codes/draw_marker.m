function frame = draw_marker(marker_loc,frame,marker_color)
    
    framecdata = frame.cdata;
    marker_loc = round(marker_loc);
    x = min(marker_loc(:,1)):max(marker_loc(:,1));
    x(find(x<1)) = [];
    x(find(x>length(framecdata(1,:,1)))) = [];
    y = min(marker_loc(:,2)):max(marker_loc(:,2));
    y(find(y<1)) = [];
    y(find(y>length(framecdata(:,1,1)))) = [];
    frame.cdata(y,x,1) = marker_color(1)*ones(length(y),length(x),1);
    frame.cdata(y,x,2) = marker_color(2)*ones(length(y),length(x),1);
    frame.cdata(y,x,3) = marker_color(3)*ones(length(y),length(x),1);
    %bottom
    for i = marker_loc(1,1):marker_loc(2,1)
        scale = (i-marker_loc(1,1))/(marker_loc(2,1)-marker_loc(1,1));
        if marker_loc(2,2)>marker_loc(1,2)
            miny = round((marker_loc(2,2)-marker_loc(1,2))*scale+marker_loc(1,2));
        elseif marker_loc(2,2)<marker_loc(1,2)
            miny = round(marker_loc(1,2)-(marker_loc(1,2)-marker_loc(2,2))*scale);
        else
            miny = marker_loc(1,2);
        end
        if miny<y(end)
            frame.cdata(miny+1:y(end),i,:) = framecdata(miny+1:y(end),i,:);
        end
    end
    if marker_loc(1,1)>x(1)
        for i = x(1):marker_loc(1,1)
            scale = (i-marker_loc(4,1))/(marker_loc(1,1)-marker_loc(4,1));
            miny = round((marker_loc(1,2)-marker_loc(4,2))*scale+marker_loc(4,2));
            try
                frame.cdata(max(miny+1,1):y(end),i,:) = framecdata(max(miny+1,1):y(end),i,:);
            catch
                disp lofasz
            end
        end
    end
    if marker_loc(2,1)<x(end)
        for i = marker_loc(2,1)+1:x(end)
            scale = (i-marker_loc(2,1))/(marker_loc(3,1)-marker_loc(2,1));
            miny = round(marker_loc(2,2)-(marker_loc(2,2)-marker_loc(3,2))*scale);
            frame.cdata(max(miny+1,1):y(end),i,:) = framecdata(max(miny+1,1):y(end),i,:);
        end
    end
    
    %top
    for i = marker_loc(4,1):marker_loc(3,1)
        scale = (i-marker_loc(4,1))/(marker_loc(3,1)-marker_loc(4,1));
        if marker_loc(4,2)>marker_loc(3,2)
            maxy = round((marker_loc(3,2)-marker_loc(4,2))*scale+marker_loc(4,2));
        elseif marker_loc(4,2)<marker_loc(3,2)
            maxy = round(marker_loc(4,2)-(marker_loc(4,2)-marker_loc(3,2))*scale);
        else
            maxy = marker_loc(4,2);
        end
        if maxy>y(1)
            frame.cdata(y(1):maxy-1,i,:) = framecdata(y(1):maxy-1,i,:);
        end
    end
    if marker_loc(4,1)>x(1)
        for i = x(1):marker_loc(4,1)
            scale = (i-marker_loc(4,1))/(marker_loc(1,1)-marker_loc(4,1));
            maxy = round((marker_loc(1,2)-marker_loc(4,2))*scale+marker_loc(4,2));
            frame.cdata(y(1):min(maxy-1,length(framecdata(:,1,1))),i,:) = framecdata(y(1):min(maxy-1,length(framecdata(:,1,1))),i,:);
        end
    end
    if marker_loc(3,1)<x(end)
        for i = marker_loc(3,1)+1:x(end)
            scale = (i-marker_loc(2,1))/(marker_loc(3,1)-marker_loc(2,1));
            maxy = round(marker_loc(2,2)-(marker_loc(2,2)-marker_loc(3,2))*scale);
            frame.cdata(y(1):min(maxy-1,length(framecdata(:,1,1))),i,:) = framecdata(y(1):min(maxy-1,length(framecdata(:,1,1))),i,:);
        end
    end
    
end