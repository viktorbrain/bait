function frame = draw_point(pos,frame,point_color,point_R,input_video)
    
    for x = max(1,floor(pos(1))-point_R):min(input_video.Width,ceil(pos(1))+point_R)
        for y = max(1,floor(pos(2))-point_R):min(input_video.Height,ceil(pos(2))+point_R)
            if round(sqrt(sumsqr([pos(1)-x pos(2)-y])))<=point_R
                frame.cdata(input_video.Height-y+1,input_video.Width-x+1,:) = point_color;
            end
        end
    end
    
end