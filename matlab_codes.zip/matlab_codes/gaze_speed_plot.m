function gaze_speed_plot(gaze_pos,fps,pathname,video_filename,ci,locvec)
    
    f = figure;
    window_size = 5;
    gaze_speed = zeros(length(gaze_pos(:,1)),1);
    for i = 2:length(gaze_pos(:,1))
        gaze_speed(i) = sqrt(sum((locvec(i,:)-gaze_pos(i,:)-(locvec(i-1,:)-gaze_pos(i-1,:))).^2));
    end
    plot((0:length(gaze_speed)-1)/fps,gaze_speed,'-b',LineWidth=1)
    hold on
    %plot((0:length(gaze_speed)-1)/fps,movmean(gaze_speed,window_size),'-r',LineWidth=2)
    gaze_speed2 = conv(gaze_speed,hamming(window_size)/window_size);
    gaze_speed2 = gaze_speed2((window_size-1)/2+1:end-(window_size-1)/2);
    plot((0:length(gaze_speed)-1)/fps,gaze_speed2,'-g',LineWidth=2)
    plot((0:length(gaze_speed)-1)/fps,5*ones(length(gaze_speed),1),'--r',LineWidth=2)
    xlabel('Time [s]')
    ylabel('Gaze speed [pixel/s]')
    grid on
    saveas(f,['.\' pathname '\' video_filename(1:ci(end)-1) '_gaze_speed.png']);
    close(f)
    
end