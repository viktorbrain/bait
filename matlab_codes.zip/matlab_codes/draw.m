function output_video_frames = draw(input_video,output_video_frames,loc_all,loc_all_vec_ip,err1,err2,ws_ids,db_ids,marker_color,point_R,gaze_R,gaze_pos)
    
    if ~isempty(gcp('nocreate'))

        nf = parallel.pool.Constant(input_video.NumFrames+1);
        loc_all_vec_ip = parallel.pool.Constant(loc_all_vec_ip);
        parfor i = 1:nf.Value
            for j = 1:length(loc_all(i).id)
                output_video_frames(i) = draw_marker(loc_all(i).loc(:,:,j),output_video_frames(i),marker_color);
            end
            if ~err1(i)
                point_color = [0 255 0];
            else
                point_color = [255 0 0];
            end
            for j = 1:length(ws_ids)
                output_video_frames(i) = draw_point(loc_all_vec_ip.Value(ws_ids(j)).loc(i,2:3),output_video_frames(i),point_color,point_R,input_video);
            end
            if ~err2(i)
                point_color = [0 255 0];
            else
                point_color = [255 0 0];
            end
            for j = 1:length(db_ids)
                output_video_frames(i) = draw_point(loc_all_vec_ip.Value(db_ids(j)).loc(i,2:3),output_video_frames(i),point_color,point_R,input_video);
            end
            output_video_frames(i) = draw_point(gaze_pos(i,:),output_video_frames(i),point_color,gaze_R,input_video);
            disp(['Process: 2\3; Draw markers: ' num2str(i) '\' num2str(nf.Value) '.'])
        end
        
    else
        
        for i = 1:input_video.NumFrames+1
            for j = 1:length(loc_all(i).id)
                output_video_frames(i) = draw_marker(loc_all(i).loc(:,:,j),output_video_frames(i),marker_color);
            end
            if ~err1(i)
                point_color = [0 255 0];
            else
                point_color = [255 0 0];
            end
            for j = 1:length(ws_ids)
                output_video_frames(i) = draw_point(loc_all_vec_ip(ws_ids(j)).loc(i,2:3),output_video_frames(i),point_color,point_R,input_video);
            end
            if ~err2(i)
                point_color = [0 255 0];
            else
                point_color = [255 0 0];
            end
            for j = 1:length(db_ids)
                output_video_frames(i) = draw_point(loc_all_vec_ip.Value(db_ids(j)).loc(i,2:3),output_video_frames(i),point_color,point_R,input_video);
            end
            output_video_frames(i) = draw_point(gaze_pos(i,:),output_video_frames(i),point_color,gaze_R,input_video);
            disp(['Process: 2\3; Draw markers: ' num2str(i) '\' num2str(input_video.NumFrames+1) '.'])
        end
        
    end
    
end