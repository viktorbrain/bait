function err = gaze_on_windscreen(loc_all_vec_ip,gaze_pos,ws_ids)
    
    ws_ids = [ws_ids ws_ids(1)];
    err = zeros(1,length(loc_all_vec_ip(ws_ids(1)).loc(:,1)));
    for i = 1:length(loc_all_vec_ip(ws_ids(1)).loc(:,1))
        x0 = gaze_pos(i,1);
        y0 = gaze_pos(i,2);
        for idi = 1:length(ws_ids)-1
            x1 = loc_all_vec_ip(ws_ids(idi)).loc(i,2);
            y1 = loc_all_vec_ip(ws_ids(idi)).loc(i,3);
            x2 = loc_all_vec_ip(ws_ids(idi+1)).loc(i,2);
            y2 = loc_all_vec_ip(ws_ids(idi+1)).loc(i,3);
            if 0>((x2-x1)*(y1-y0)-(x1-x0)*(y2-y1))/sqrt((x2-x1)^2+(y1-y2)^2)
                err(i) = 1;
                break
            end
        end
    end
    
end