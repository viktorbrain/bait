% gaze_localizer('040_BD130T','world.mp4','gaze_positions.csv','marker_detections.csv','tag36h11',8)
function gaze_localizer(pathname,video_filename,gaze_data_filename,marker_data_filename,tag_family,tag_number)
    
    number_of_threads = 8;
    
    gaze_R = 10;
    point_R = 10;
    marker_color = [0 0 255];
    extension = [100 150 170 300];
    ws_ids = [6 4 5 7];
    ws_ids_points = [4 1 2 3;
                     4 1 2 3];
    db_ids = [3 1 8 2];
    db_ids_points = [2 3 4 1;
                     2 3 4 1];

    if number_of_threads > 1
        if isempty(gcp('nocreate'))
            parpool(number_of_threads);
        end
    else
        if ~isempty(gcp('nocreate'))
            delete(gcp);
        end
    end
    
    input_video = VideoReader(['.\' pathname '\' video_filename]);
    input_video_frames = read(input_video);
    ci = strfind(video_filename,'.');
    output_video = VideoWriter(['.\' pathname '\' video_filename(1:ci(end)-1) '_output']);
    output_video.FrameRate = input_video.FrameRate;
    gaze = readtable(['.\' pathname '\' gaze_data_filename]);
    
    gaze_pos = zeros(input_video.NumFrames+1,2);
    for i = 1:input_video.NumFrames+1
        gaze_pos_data = find(gaze.world_index+1-gaze.world_index(1)==i);
        if ~isempty(gaze_pos_data)
            gaze_pos(i,:) = [1-mean(gaze.norm_pos_x(gaze_pos_data)) mean(gaze.norm_pos_y(gaze_pos_data))].*[input_video.Width input_video.Height];
        end
    end
    gaze_pos_data = find(gaze_pos(:,1));
    gaze_pos(:,1) = interp1(gaze_pos_data,gaze_pos(gaze_pos_data,1),(1:input_video.NumFrames+1)','linear','extrap');
    gaze_pos_data = find(gaze_pos(:,2));
    gaze_pos(:,2) = interp1(gaze_pos_data,gaze_pos(gaze_pos_data,2),(1:input_video.NumFrames+1)','linear','extrap');
    
    marker = readtable(['.\' pathname '\' marker_data_filename]);
    detected_markers_n1 = zeros(1,tag_number);
    for i = 1:height(marker)
        dp = strfind(marker.marker_uid{i},':');
        detected_markers_n1(str2double(marker.marker_uid{i}(dp(end)+1:end))) = detected_markers_n1(str2double(marker.marker_uid{i}(dp(end)+1:end)))+1;
    end

    tic
    [loc_all, output_video_frames] = detect_markers(input_video,input_video_frames,tag_family);
    detected_markers_n2 = zeros(1,tag_number);
    for i = 1:length(loc_all)
        detected_markers_n2(loc_all(i).id) = detected_markers_n2(loc_all(i).id)+1;
    end
    loc_all_vec_ip = windscreen_coords(loc_all,ws_ids,ws_ids_points,db_ids,db_ids_points,input_video,extension);
    err1 = gaze_on_windscreen(loc_all_vec_ip,gaze_pos,ws_ids);
    err2 = gaze_on_windscreen(loc_all_vec_ip,gaze_pos,db_ids);
    process_time = toc;
    gaze_speed_plot(gaze_pos,output_video.FrameRate,pathname,video_filename,ci,loc_all_vec_ip(6).loc(:,2:3));
    output_video_frames = draw(input_video,output_video_frames,loc_all,loc_all_vec_ip,err1,err2,ws_ids,db_ids,marker_color,point_R,gaze_R,gaze_pos);
    save(['.\' pathname '\' video_filename(1:ci(end)-1) '_output.mat'],'loc_all','output_video_frames','loc_all_vec_ip','err1','err2','process_time','detected_markers_n1','detected_markers_n2','-v7.3')
    open(output_video);
    for i = 1:input_video.NumFrames+1
        writeVideo(output_video, output_video_frames(i))
        disp(['Process: 3\3; Export video: ' num2str(i) '\' num2str(input_video.NumFrames+1) '.'])
    end
    close(output_video)
    
end