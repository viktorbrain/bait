function [loc_all, output_video_frames] = detect_markers(input_video,input_video_frames,tag_family)
    
    loc_all = struct('loc',num2cell(1:input_video.NumFrames+1),'id',num2cell(1:input_video.NumFrames+1));
    output_video_frames = struct('cdata',num2cell(1:input_video.NumFrames+1),'colormap',num2cell(1:input_video.NumFrames+1));

    if ~isempty(gcp('nocreate'))
        
        for i = 1:input_video.NumFrames+1
            output_video_frames(i).cdata = input_video_frames(:,:,:,i);
            output_video_frames(i).colormap = [];
        end
        nf = parallel.pool.Constant(input_video.NumFrames+1);
        parfor i = 1:nf.Value
            [id,loc] = readAprilTag(output_video_frames(i).cdata,tag_family);
            for j = 0:0.2:1
                BW = imbinarize(output_video_frames(i).cdata,'adaptive','ForegroundPolarity','dark','Sensitivity',j);
                for rgb = 1:3
                    [id2,loc2] = readAprilTag(BW(:,:,rgb),tag_family);
                    [id, idi] = unique([id id2]);
                    loc = cat(3,loc,loc2);
                    loc = loc(:,:,idi);
                end
            end
            loc_all(i).loc = loc;
            loc_all(i).id = id;
            
            disp(['Process: 1\3; Detect markers: ' num2str(i) '\' num2str(nf.Value) '.'])
            
        end
        
    else
        
        for i = 1:input_video.NumFrames+1
            output_video_frames(i).cdata = input_video_frames(:,:,:,i);
            output_video_frames(i).colormap = [];
            id = [];
            loc = [];
            for j = 0:0.2:1
                BW = imbinarize(output_video_frames(i).cdata,'adaptive','ForegroundPolarity','dark','Sensitivity',j);
                for rgb = 1:3
                    [id2,loc2] = readAprilTag(BW(:,:,rgb),tag_family);
                    [id, idi] = unique([id id2]);
                    loc = cat(3,loc,loc2);
                    loc = loc(:,:,idi);
                end
            end
            loc_all(i).loc = loc;
            loc_all(i).id = id;
            
            disp(['Process: 1\3; Detect markers: ' num2str(i) '\' num2str(input_video.NumFrames+1) '.'])
            
        end
        
    end
    
    detected_makrer_n = 0;
    for i = 1:input_video.NumFrames+1
        detected_makrer_n = detected_makrer_n + length(loc_all(i).id);
    end
    disp(['Detected markers: ' num2str(detected_makrer_n)])
    
end