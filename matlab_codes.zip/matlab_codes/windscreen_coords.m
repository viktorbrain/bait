function loc_all_vec_ip = windscreen_coords(loc_all,ws_ids,ws_ids_points,db_ids,db_ids_points,input_video,extension)
    
    fields = fieldnames(loc_all);
    for i = 1:length(fields)
        if strcmp(fields{i},'id')
            id_field_n = i;
            break
        end
    end
    ids = struct2cell(loc_all);
    idn = unique(cell2mat(squeeze(ids(id_field_n,:,:))'));
    idn = unique([idn ws_ids db_ids]);
    
    loc_all_vec = struct('loc',num2cell(1:length(idn)),'id',num2cell(1:length(idn)));
    for i = 1:length(idn)
        loc_all_vec(i).loc =  [];
    end
    for i = 1:length(loc_all)
        for id = 1:length(ws_ids)
            idi = find(loc_all(i).id==ws_ids(id));
            if ~isempty(idi)
                x = mean([loc_all(i).loc(ws_ids_points(1,id),1,idi), loc_all(i).loc(ws_ids_points(2,id),1,idi)]);
                y = mean([loc_all(i).loc(ws_ids_points(1,id),2,idi), loc_all(i).loc(ws_ids_points(2,id),2,idi)]);
                loc_all_vec(ws_ids(id)).loc = [loc_all_vec(ws_ids(id)).loc; [i, x, y]];
            end
        end
        for id = 1:length(db_ids)
            idi = find(loc_all(i).id==db_ids(id));
            if ~isempty(idi)
                x = mean([loc_all(i).loc(db_ids_points(1,id),1,idi), loc_all(i).loc(db_ids_points(2,id),1,idi)]);
                y = mean([loc_all(i).loc(db_ids_points(1,id),2,idi), loc_all(i).loc(db_ids_points(2,id),2,idi)]);
                loc_all_vec(db_ids(id)).loc = [loc_all_vec(db_ids(id)).loc; [i, x, y]];
            end
        end
    end
    loc_all_vec_ip = loc_all_vec;
    for id = 1:length(ws_ids)
        if isempty(loc_all_vec_ip(ws_ids(id)).loc)
            loc_all_vec_ip(ws_ids(id)).loc = ([(1:length(loc_all))' zeros(length(loc_all),2)]);
        else
            loc_all_vec_ip(ws_ids(id)).loc = round([(1:length(loc_all))', interp1(loc_all_vec(ws_ids(id)).loc(:,1),loc_all_vec(ws_ids(id)).loc(:,2),1:length(loc_all),'linear','extrap')', interp1(loc_all_vec(ws_ids(id)).loc(:,1),loc_all_vec(ws_ids(id)).loc(:,3),1:length(loc_all),'linear','extrap')']);
            loc_all_vec_ip(ws_ids(id)).loc(:,2:3) = [input_video.Width+1 input_video.Height+1]-loc_all_vec_ip(ws_ids(id)).loc(:,2:3);
        end
    end
    for id = 1:length(db_ids)
        if isempty(loc_all_vec_ip(db_ids(id)).loc)
            loc_all_vec_ip(db_ids(id)).loc = ([(1:length(loc_all))' zeros(length(loc_all),2)]);
        else
            loc_all_vec_ip(db_ids(id)).loc = round([(1:length(loc_all))', interp1(loc_all_vec(db_ids(id)).loc(:,1),loc_all_vec(db_ids(id)).loc(:,2),1:length(loc_all),'linear','extrap')', interp1(loc_all_vec(db_ids(id)).loc(:,1),loc_all_vec(db_ids(id)).loc(:,3),1:length(loc_all),'linear','extrap')']);
            loc_all_vec_ip(db_ids(id)).loc(:,2:3) = [input_video.Width+1 input_video.Height+1]-loc_all_vec_ip(db_ids(id)).loc(:,2:3);
        end
    end
    if extension(1)>0
        p1p2 = loc_all_vec_ip(ws_ids(1)).loc(:,2:3)-loc_all_vec_ip(ws_ids(2)).loc(:,2:3);
        loc_all_vec_ip(ws_ids(1)).loc(:,2) = (extension(1)./sqrt(p1p2(:,1).^2+p1p2(:,2).^2)).*p1p2(:,1)+loc_all_vec_ip(ws_ids(1)).loc(:,2);
        loc_all_vec_ip(ws_ids(1)).loc(:,3) = (extension(1)./sqrt(p1p2(:,1).^2+p1p2(:,2).^2)).*p1p2(:,2)+loc_all_vec_ip(ws_ids(1)).loc(:,3);
    end
    if extension(2)>0
        p4p3 = loc_all_vec_ip(ws_ids(4)).loc(:,2:3)-loc_all_vec_ip(ws_ids(3)).loc(:,2:3);
        loc_all_vec_ip(ws_ids(4)).loc(:,2) = (extension(2)./sqrt(p4p3(:,1).^2+p4p3(:,2).^2)).*p4p3(:,1)+loc_all_vec_ip(ws_ids(4)).loc(:,2);
        loc_all_vec_ip(ws_ids(4)).loc(:,3) = (extension(2)./sqrt(p4p3(:,1).^2+p4p3(:,2).^2)).*p4p3(:,2)+loc_all_vec_ip(ws_ids(4)).loc(:,3);
    end
    if extension(3)>0
        p2p3 = loc_all_vec_ip(ws_ids(2)).loc(:,2:3)-loc_all_vec_ip(ws_ids(3)).loc(:,2:3);
        loc_all_vec_ip(db_ids(4)).loc(:,2) = (extension(3)./sqrt(p2p3(:,1).^2+p2p3(:,2).^2)).*p2p3(:,1)+loc_all_vec_ip(db_ids(1)).loc(:,2);
        loc_all_vec_ip(db_ids(4)).loc(:,3) = (extension(3)./sqrt(p2p3(:,1).^2+p2p3(:,2).^2)).*p2p3(:,2)+loc_all_vec_ip(db_ids(1)).loc(:,3);
%         loc_all_vec_ip(db_ids(4)).loc(:,2) = loc_all_vec_ip(db_ids(1)).loc(:,2)+extension(3);
%         loc_all_vec_ip(db_ids(4)).loc(:,3) = loc_all_vec_ip(db_ids(1)).loc(:,3);
    end
    if extension(4)>0
        p2p3 = loc_all_vec_ip(ws_ids(2)).loc(:,2:3)-loc_all_vec_ip(ws_ids(3)).loc(:,2:3);
        loc_all_vec_ip(db_ids(3)).loc(:,2) = (extension(4)./sqrt(p2p3(:,1).^2+p2p3(:,2).^2)).*p2p3(:,1)+loc_all_vec_ip(db_ids(2)).loc(:,2);
        loc_all_vec_ip(db_ids(3)).loc(:,3) = (extension(4)./sqrt(p2p3(:,1).^2+p2p3(:,2).^2)).*p2p3(:,2)+loc_all_vec_ip(db_ids(2)).loc(:,3);
%         loc_all_vec_ip(db_ids(3)).loc(:,2) = loc_all_vec_ip(db_ids(2)).loc(:,2)+extension(4);
%         loc_all_vec_ip(db_ids(3)).loc(:,3) = loc_all_vec_ip(db_ids(2)).loc(:,3);
    end

end